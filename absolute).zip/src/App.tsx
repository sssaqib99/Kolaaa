// Intentionally blank.
// This deliverable is a Godot 4 project (GDScript only) located in /hyperdrift.
// No web page, no landing page — open `hyperdrift/project.godot` in Godot and press F5.
export default function App() {
  return null;
}
